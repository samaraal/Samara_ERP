import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";
import "../_shared/food-vendor-core.js";
const core=(globalThis as any).SamaraFoodCore;
const headers={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS","Content-Type":"application/json"};
Deno.serve(async req=>{
 const reply=(data:unknown,status=200)=>new Response(JSON.stringify(data),{headers,status});
 if(req.method==='OPTIONS')return new Response('ok',{headers});if(req.method!=='POST')return reply({error:'POST required'},405);
 const url=Deno.env.get('SUPABASE_URL')!,key=Deno.env.get('SUPABASE_ANON_KEY')!,service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
 const user=createClient(url,key,{global:{headers:{Authorization:req.headers.get('Authorization')||''}},auth:{persistSession:false}});
 const admin=createClient(url,service,{auth:{persistSession:false}});let id='',claimed=false;
 try{
  const jwt=(req.headers.get('Authorization')||'').replace(/^Bearer\s+/i,'').trim();
  if(!jwt)return reply({error:'Sign in required'},401);
  const {data:{user:identity},error:authError}=await user.auth.getUser(jwt);if(authError||!identity)return reply({error:'Session verification failed: '+(authError?.message||'No signed-in user')},401);
  const input=await req.json();id=String(input.id||'');
  const token=Deno.env.get('WHATSAPP_ACCESS_TOKEN'),number=Deno.env.get('WHATSAPP_PHONE_NUMBER_ID');if(!token||!number)throw Error('WhatsApp server configuration missing');
  if(input.action==='check'){const {data:a,error}=await user.rpc('fv_access');if(error||!a?.control)return reply({error:'Food order authority required'},403);return reply({success:true,message:'Authenticated food sender and WhatsApp settings are available. No message was sent.'});}
  const {data:msg,error}=await user.rpc('fv_rpc',{action:'claim',p:{id,request_id:crypto.randomUUID()}});if(error)throw error;claimed=true;
  let body;try{body=core.payload(msg.kind,msg.snapshot)}catch(e){await admin.from('fv_messages').update({status:'Failed',error:String(e),updated_at:new Date().toISOString()}).eq('id',id);claimed=false;throw e;}
  const response=await fetch(`https://graph.facebook.com/v25.0/${number}/messages`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(25000)});
  const data=await response.json();
  if(!response.ok){const errorText=String(data?.error?.message||'Meta rejected the message');await admin.from('fv_messages').update({status:response.status>=500?'Unknown':'Failed',error:errorText,updated_at:new Date().toISOString()}).eq('id',id);claimed=false;return reply({error:errorText},400)}
  const provider=data?.messages?.[0]?.id;if(!provider)throw Error('No provider message ID; outcome is uncertain');
  const {error:saveError}=await admin.from('fv_messages').update({provider_id:provider,status:'Accepted',error:null,updated_at:new Date().toISOString()}).eq('id',id);
  if(saveError)throw Error('Meta accepted, but history save failed. Do not resend. Provider ID: '+provider);
  await admin.rpc('fv_apply_provider_status',{p_id:provider,p_status:'Accepted',p_detail:null,p_at:new Date().toISOString()});
  return reply({success:true,status:'Accepted',provider_id:provider});
 }catch(e){const error=e instanceof Error?e.message:String((e as any)?.message||e);if(claimed)await admin.from('fv_messages').update({status:'Unknown',error,updated_at:new Date().toISOString()}).eq('id',id);return reply({error},400)}
});
